import React from 'react'

const Default = () => {
  return (
    <>
        This is dafault page
    </>
  )
}

export default Default