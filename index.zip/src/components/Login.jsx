import React from 'react'

const Login = () => {
  return (
    <>
        This is login page
    </>
  )
}

export default Login