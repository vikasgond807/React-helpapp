import React from "react";
import {
  ProSidebar,
  Menu,
  MenuItem,
  // SubMenu,
  SidebarHeader,
} from "react-pro-sidebar";
import { FaGem } from "react-icons/fa";
import "react-pro-sidebar/dist/css/styles.css";
import { Link } from "react-router-dom";
const Sidebar = () => {
  return (
    <>
      <ProSidebar>
        <SidebarHeader>
          <h3 style={{ textAlign: "center" }} className="heading">
            Your App Name
          </h3>
        </SidebarHeader>
        <Menu iconShape="square">
          <MenuItem icon={<FaGem />}>
            <Link to="/login">Login</Link>
          </MenuItem>
          <MenuItem icon={<FaGem />}>
            <Link to="/register">Register</Link>
          </MenuItem>
          <MenuItem icon={<FaGem />}>
            <Link to="/default">Default Gesture</Link>
          </MenuItem>
          <MenuItem icon={<FaGem />}>
            <Link to="/default">Add Gesture</Link>
          </MenuItem>
        </Menu>
      </ProSidebar>
    </>
  );
};

export default Sidebar;
