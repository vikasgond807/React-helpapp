import React from 'react'

const Register = () => {
  return (
    <>
        this is register page
    </>
  )
}

export default Register