import "./App.css";
import Sidebar from "./components/Sidebar";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./components/Login";
import Register from "./components/Register";
import Default from "./components/Default";

function App() {
  return (
    <>
      <Router>
        <div className="main">
          <div className="sidebar">
            <Sidebar />
          </div>
          <div className="paths">
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/default" element={<Default />} />
            </Routes>
          </div>
        </div>
      </Router>
    </>
  );
}

export default App;
